from pathlib import Path
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from .db import init_db
from .api import router
app=FastAPI(title="Telegram Stream Bot V2")
app.include_router(router)
@app.on_event("startup")
async def startup(): await init_db()
frontend=Path(__file__).resolve().parent.parent/"frontend"
app.mount("/static",StaticFiles(directory=frontend),name="static")
@app.get("/")
async def index():return FileResponse(frontend/"index.html")
if __name__=="__main__":
 import uvicorn;uvicorn.run("app.main:app",host="0.0.0.0",port=8000)
