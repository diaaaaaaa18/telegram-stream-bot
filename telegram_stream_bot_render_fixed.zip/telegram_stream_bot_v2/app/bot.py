import asyncio,logging
from aiogram import Bot,Dispatcher,Router,F
from aiogram.filters import CommandStart,Command
from aiogram.types import Message,CallbackQuery,InlineKeyboardMarkup,InlineKeyboardButton,WebAppInfo
from aiogram.enums import ChatMemberStatus
from sqlalchemy import select,func
from .config import settings
from .db import init_db,SessionLocal
from .models import User,Admin,RequiredChannel,Stream

logging.basicConfig(level=logging.INFO);router=Router()
pending={}

async def is_admin(tid,role=None):
    async with SessionLocal() as s:
        q=select(Admin).where(Admin.telegram_id==tid)
        a=(await s.execute(q)).scalar_one_or_none()
        return a if a and (role is None or (role=="super" and a.role=="super")) else None

async def ensure_user(m):
    async with SessionLocal() as s:
        u=(await s.execute(select(User).where(User.telegram_id==m.from_user.id))).scalar_one_or_none()
        if not u:s.add(User(telegram_id=m.from_user.id,username=m.from_user.username,first_name=m.from_user.first_name))
        await s.commit()

async def channels():
    async with SessionLocal() as s:return (await s.execute(select(RequiredChannel).where(RequiredChannel.enabled.is_(True)))).scalars().all()

async def subscribed(bot,uid):
    for c in await channels():
        try:
            m=await bot.get_chat_member(c.chat_id,uid)
            if m.status in {ChatMemberStatus.LEFT,ChatMemberStatus.KICKED}:return False
        except:return False
    return True

def admin_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
      [InlineKeyboardButton(text="📺 إدارة البثوث",callback_data="adm_streams")],
      [InlineKeyboardButton(text="📢 القنوات الإجبارية",callback_data="adm_channels")],
      [InlineKeyboardButton(text="👨‍💻 إدارة الأدمن",callback_data="adm_admins")],
      [InlineKeyboardButton(text="📣 إذاعة",callback_data="adm_broadcast")],
      [InlineKeyboardButton(text="📊 الإحصائيات",callback_data="adm_stats")],
      [InlineKeyboardButton(text="🔗 فتح التطبيق",web_app=WebAppInfo(url=settings.webapp_url))]])

@router.message(CommandStart())
async def start(m:Message,bot:Bot):
    await ensure_user(m)
    if not await subscribed(bot,m.from_user.id):
        cs=await channels(); rows=[[InlineKeyboardButton(text=f"📢 {c.title}",url=c.invite_url)] for c in cs]
        rows.append([InlineKeyboardButton(text="✅ تحقق",callback_data="check_sub")])
        await m.answer("اشترك في القنوات المطلوبة أولًا.",reply_markup=InlineKeyboardMarkup(inline_keyboard=rows));return
    if await is_admin(m.from_user.id):
        await m.answer("🎛 لوحة الإدارة\nاختر العملية:",reply_markup=admin_kb())
    else:
        await m.answer("🎬 أهلاً بك",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="📺 مشاهدة البثوث",web_app=WebAppInfo(url=settings.webapp_url))]]))

@router.message(Command("admin"))
async def admin_cmd(m:Message):
    if await is_admin(m.from_user.id): await m.answer("🎛 لوحة الإدارة",reply_markup=admin_kb())
    else: await m.answer("غير مصرح.")

@router.callback_query(F.data=="check_sub")
async def check(c:CallbackQuery,bot:Bot):
    if await subscribed(bot,c.from_user.id): await c.message.answer("✅ تم التحقق. أرسل /start.")
    else: await c.answer("❌ ما زال الاشتراك مطلوبًا.",show_alert=True)

@router.callback_query(F.data=="adm_stats")
async def stats(c:CallbackQuery):
    if not await is_admin(c.from_user.id):return
    async with SessionLocal() as s:
        u=await s.scalar(select(func.count(User.id)));st=await s.scalar(select(func.count(Stream.id)));v=await s.scalar(select(func.sum(Stream.views)))
    await c.message.answer(f"📊 الإحصائيات\n\n👥 المستخدمون: {u or 0}\n📺 البثوث: {st or 0}\n👁 المشاهدات: {v or 0}")

@router.callback_query(F.data=="adm_streams")
async def adm_streams(c:CallbackQuery):
    if not await is_admin(c.from_user.id):return
    kb=InlineKeyboardMarkup(inline_keyboard=[
      [InlineKeyboardButton(text="➕ إضافة بث",callback_data="add_stream")],
      [InlineKeyboardButton(text="📋 قائمة/حذف",callback_data="list_streams")],
      [InlineKeyboardButton(text="⬅️ الرئيسية",callback_data="back_admin")]])
    await c.message.answer("📺 إدارة البثوث",reply_markup=kb)

@router.callback_query(F.data=="add_stream")
async def add_stream(c:CallbackQuery):
    if await is_admin(c.from_user.id):
        pending[c.from_user.id]={"step":"title"}
        await c.message.answer("أرسل اسم البث.")

@router.message()
async def state(m:Message,bot:Bot):
    tid=m.from_user.id
    if tid not in pending:return
    if not await is_admin(tid):pending.pop(tid,None);return
    p=pending[tid];step=p["step"]
    if step=="title":p["title"]=m.text;p["step"]="iframe";await m.answer("أرسل الآن كود iframe كامل.")
    elif step=="iframe":
        p["iframe_code"]=m.text;p["step"]="image";await m.answer("أرسل رابط الصورة أو اكتب - لتخطيها.")
    elif step=="image":
        p["image_url"]=None if m.text.strip()=="-" else m.text.strip()
        async with SessionLocal() as s:
            from .iframe import sanitize_iframe
            try: iframe=sanitize_iframe(p["iframe_code"])
            except ValueError as e: await m.answer("❌ "+str(e));return
            s.add(Stream(title=p["title"],iframe_code=iframe,image_url=p["image_url"],status="live"));await s.commit()
        pending.pop(tid,None);await m.answer("✅ تم إضافة البث.",reply_markup=admin_kb())

@router.callback_query(F.data=="list_streams")
async def list_streams(c:CallbackQuery):
    if not await is_admin(c.from_user.id):return
    async with SessionLocal() as s: rows=(await s.execute(select(Stream).order_by(Stream.id.desc()))).scalars().all()
    if not rows:return await c.message.answer("لا توجد بثوث.")
    for x in rows:
        kb=InlineKeyboardMarkup(inline_keyboard=[
          [InlineKeyboardButton(text="🗑 حذف",callback_data=f"del_stream:{x.id}"),
           InlineKeyboardButton(text=("⏸ إيقاف" if x.enabled else "▶️ تفعيل"),callback_data=f"toggle:{x.id}")]])
        await c.message.answer(f"#{x.id} — {x.title}\n{('🟢 فعال' if x.enabled else '🔴 متوقف')}\n👁 {x.views}",reply_markup=kb)

@router.callback_query(F.data.startswith("del_stream:"))
async def del_stream(c:CallbackQuery):
    if not await is_admin(c.from_user.id):return
    sid=int(c.data.split(":")[1])
    async with SessionLocal() as s:
        x=await s.get(Stream,sid)
        if x:await s.delete(x);await s.commit()
    await c.answer("تم الحذف");await c.message.edit_text("🗑 تم حذف البث.")

@router.callback_query(F.data.startswith("toggle:"))
async def toggle(c:CallbackQuery):
    if not await is_admin(c.from_user.id):return
    sid=int(c.data.split(":")[1])
    async with SessionLocal() as s:
        x=await s.get(Stream,sid)
        if x:x.enabled=not x.enabled;await s.commit()
    await c.answer("تم التغيير")

@router.callback_query(F.data=="adm_admins")
async def admins(c:CallbackQuery):
    a=await is_admin(c.from_user.id,"super")
    if not a:return await c.answer("هذه العملية للـ Super Admin فقط",show_alert=True)
    await c.message.answer("👨‍💻 لإضافة أدمن: أرسل /addadmin USER_ID\nللحذف: /deladmin USER_ID")

@router.message(Command("addadmin"))
async def addadmin(m:Message):
    if not await is_admin(m.from_user.id,"super"):return
    parts=m.text.split()
    if len(parts)!=2:return await m.answer("الاستخدام: /addadmin 123456789")
    tid=int(parts[1])
    async with SessionLocal() as s:
        old=(await s.execute(select(Admin).where(Admin.telegram_id==tid))).scalar_one_or_none()
        if not old:s.add(Admin(telegram_id=tid,role="admin"));await s.commit()
    await m.answer("✅ تم إضافة الأدمن.")

@router.message(Command("deladmin"))
async def deladmin(m:Message):
    if not await is_admin(m.from_user.id,"super"):return
    parts=m.text.split()
    if len(parts)!=2:return await m.answer("الاستخدام: /deladmin 123456789")
    tid=int(parts[1])
    async with SessionLocal() as s:
        a=(await s.execute(select(Admin).where(Admin.telegram_id==tid))).scalar_one_or_none()
        if a and a.role!="super":await s.delete(a);await s.commit()
    await m.answer("✅ تم حذف الأدمن.")

@router.callback_query(F.data=="adm_channels")
async def adm_channels(c:CallbackQuery):
    if not await is_admin(c.from_user.id,"super"):return await c.answer("Super Admin فقط",show_alert=True)
    await c.message.answer("📢 إدارة القنوات:\n/addchannel CHAT_ID | العنوان | رابط_الاشتراك\n/delchannel CHAT_ID")

@router.message(Command("addchannel"))
async def addchannel(m:Message):
    if not await is_admin(m.from_user.id,"super"):return
    try:
        chat_id,title,url=[x.strip() for x in m.text.split("|",2)]
        async with SessionLocal() as s:
            s.add(RequiredChannel(chat_id=int(chat_id),title=title,invite_url=url));await s.commit()
        await m.answer("✅ تمت إضافة القناة.")
    except:await m.answer("الصيغة: /addchannel CHAT_ID | العنوان | الرابط")

@router.message(Command("delchannel"))
async def delchannel(m:Message):
    if not await is_admin(m.from_user.id,"super"):return
    try:cid=int(m.text.split()[1])
    except:return
    async with SessionLocal() as s:
        c=(await s.execute(select(RequiredChannel).where(RequiredChannel.chat_id==cid))).scalar_one_or_none()
        if c:await s.delete(c);await s.commit()
    await m.answer("✅ تم حذف القناة.")

@router.callback_query(F.data=="adm_broadcast")
async def broadcast_start(c:CallbackQuery):
    if not await is_admin(c.from_user.id,"super"):return await c.answer("Super Admin فقط",show_alert=True)
    pending[c.from_user.id]={"step":"broadcast"};await c.message.answer("📣 أرسل نص الإذاعة الآن.")

async def do_broadcast(bot,admin_id,text):
    async with SessionLocal() as s: users=(await s.execute(select(User).where(User.blocked.is_(False)))).scalars().all()
    ok=bad=0
    for u in users:
        try:await bot.send_message(u.telegram_id,text);ok+=1
        except Exception:
            bad+=1
            if "blocked" in str(_).lower() if False else False: pass
        await asyncio.sleep(settings.broadcast_delay)
    return ok,bad

@router.callback_query(F.data=="back_admin")
async def back(c:CallbackQuery):
    if await is_admin(c.from_user.id):await c.message.answer("🎛 لوحة الإدارة",reply_markup=admin_kb())

async def main():
    await init_db()
    bot=Bot(settings.bot_token);dp=Dispatcher();dp.include_router(router)
    # Bootstrap first Super Admin from ADMIN_IDS.
    async with SessionLocal() as s:
        for tid in settings.admin_ids:
            a=(await s.execute(select(Admin).where(Admin.telegram_id==tid))).scalar_one_or_none()
            if not a:s.add(Admin(telegram_id=tid,role="super"))
        await s.commit()
    await dp.start_polling(bot)

if __name__=="__main__":asyncio.run(main())
