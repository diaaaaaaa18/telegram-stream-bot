import re
from html import escape
from urllib.parse import urlparse
from .config import settings
IFRAME_RE=re.compile(r'<iframe\\b([^>]*)>.*?</iframe>',re.I|re.S)
SRC_RE=re.compile(r'''\\bsrc\\s*=\\s*["']([^"']+)["']''',re.I)
def sanitize_iframe(code):
    m=IFRAME_RE.fullmatch(code.strip())
    if not m: raise ValueError("أرسل كود iframe كاملًا.")
    sm=SRC_RE.search(m.group(1))
    if not sm: raise ValueError("iframe يجب أن يحتوي على src.")
    src=sm.group(1).strip(); u=urlparse(src)
    if u.scheme not in ("http","https") or not u.netloc: raise ValueError("رابط iframe غير صالح.")
    host=(u.hostname or "").lower()
    if settings.allowed_iframe_hosts and not any(host==h or host.endswith("."+h) for h in settings.allowed_iframe_hosts):
        raise ValueError("النطاق غير مسموح.")
    return f'<iframe src="{escape(src,quote=True)}" style="width:100%;height:100%;border:0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen loading="lazy" referrerpolicy="no-referrer"></iframe>'
