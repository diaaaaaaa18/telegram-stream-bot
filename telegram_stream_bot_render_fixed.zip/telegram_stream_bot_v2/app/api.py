import json
from datetime import datetime,timezone,timedelta
from fastapi import APIRouter,HTTPException,Header,Query
from sqlalchemy import select,func
from .db import SessionLocal
from .models import User,Admin,Stream,View
from .security import validate_telegram_init_data
from .iframe import sanitize_iframe
router=APIRouter()

async def auth(h):
    if not h: raise HTTPException(401,"افتح التطبيق من داخل Telegram")
    try:
        d=validate_telegram_init_data(h); u=json.loads(d["user"]); return int(u["id"]),u
    except Exception as e: raise HTTPException(401,str(e))
async def admin(tid):
    async with SessionLocal() as s:
        return (await s.execute(select(Admin).where(Admin.telegram_id==tid))).scalar_one_or_none()

@router.post("/api/session")
async def session(x_telegram_init_data:str|None=Header(default=None)):
    tid,u=await auth(x_telegram_init_data)
    async with SessionLocal() as s:
        row=(await s.execute(select(User).where(User.telegram_id==tid))).scalar_one_or_none()
        if not row:
            row=User(telegram_id=tid,username=u.get("username"),first_name=u.get("first_name"));s.add(row)
        row.last_active=datetime.now(timezone.utc);await s.commit()
    return {"ok":True,"user_id":tid,"admin":bool(await admin(tid))}

@router.get("/api/streams")
async def streams(x_telegram_init_data:str|None=Header(default=None),q:str=Query("")):
    await auth(x_telegram_init_data)
    async with SessionLocal() as s:
        st=select(Stream).where(Stream.enabled.is_(True)).order_by(Stream.sort_order,Stream.id.desc())
        if q.strip(): st=st.where(Stream.title.ilike(f"%{q.strip()}%"))
        return [{"id":x.id,"title":x.title,"description":x.description,"image_url":x.image_url,"status":x.status,"views":x.views} for x in (await s.execute(st)).scalars().all()]

@router.get("/api/streams/{sid}")
async def stream(sid:int,x_telegram_init_data:str|None=Header(default=None)):
    tid,_=await auth(x_telegram_init_data)
    async with SessionLocal() as s:
        x=await s.get(Stream,sid)
        if not x or not x.enabled: raise HTTPException(404,"البث غير موجود")
        x.views+=1;s.add(View(stream_id=sid,telegram_id=tid));await s.commit()
        return {"id":x.id,"title":x.title,"description":x.description,"image_url":x.image_url,"status":x.status,"views":x.views,"iframe":x.iframe_code}

@router.get("/api/admin/dashboard")
async def dashboard(x_telegram_init_data:str|None=Header(default=None)):
    tid,_=await auth(x_telegram_init_data)
    if not await admin(tid): raise HTTPException(403,"Admin only")
    async with SessionLocal() as s:
        users=await s.scalar(select(func.count(User.id))); streams=await s.scalar(select(func.count(Stream.id))); views=await s.scalar(select(func.count(View.id)))
        since=datetime.now(timezone.utc)-timedelta(days=1)
        active=await s.scalar(select(func.count(User.id)).where(User.last_active>=since))
        return {"users":users or 0,"streams":streams or 0,"views":views or 0,"active_24h":active or 0}

@router.post("/api/admin/streams")
async def create_stream(p:dict,x_telegram_init_data:str|None=Header(default=None)):
    tid,_=await auth(x_telegram_init_data)
    if not await admin(tid): raise HTTPException(403,"Admin only")
    try: iframe=sanitize_iframe(p.get("iframe_code",""))
    except ValueError as e: raise HTTPException(400,str(e))
    title=str(p.get("title","")).strip()
    if not title: raise HTTPException(400,"اسم البث مطلوب")
    async with SessionLocal() as s:
        x=Stream(title=title,description=p.get("description"),image_url=p.get("image_url"),iframe_code=iframe,status=p.get("status","live"),sort_order=int(p.get("sort_order",0)))
        s.add(x);await s.commit();await s.refresh(x);return {"ok":True,"id":x.id}

@router.patch("/api/admin/streams/{sid}")
async def update_stream(sid:int,p:dict,x_telegram_init_data:str|None=Header(default=None)):
    tid,_=await auth(x_telegram_init_data)
    if not await admin(tid): raise HTTPException(403,"Admin only")
    async with SessionLocal() as s:
        x=await s.get(Stream,sid)
        if not x: raise HTTPException(404,"Not found")
        for k in ("title","description","image_url","status","enabled","sort_order"):
            if k in p: setattr(x,k,p[k])
        if "iframe_code" in p: x.iframe_code=sanitize_iframe(p["iframe_code"])
        await s.commit();return {"ok":True}

@router.delete("/api/admin/streams/{sid}")
async def delete_stream(sid:int,x_telegram_init_data:str|None=Header(default=None)):
    tid,_=await auth(x_telegram_init_data)
    if not await admin(tid): raise HTTPException(403,"Admin only")
    async with SessionLocal() as s:
        x=await s.get(Stream,sid)
        if not x: raise HTTPException(404,"Not found")
        await s.delete(x);await s.commit()
    return {"ok":True}
