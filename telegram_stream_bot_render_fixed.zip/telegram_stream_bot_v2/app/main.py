import asyncio
import os
from pathlib import Path

import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from .db import init_db
from .api import router
from .bot import main as bot_main

app = FastAPI(title="Telegram Stream Bot V2")
app.include_router(router)

@app.on_event("startup")
async def startup():
    await init_db()
    app.state.bot_task = asyncio.create_task(bot_main())

@app.on_event("shutdown")
async def shutdown():
    task = getattr(app.state, "bot_task", None)
    if task:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

frontend = Path(__file__).resolve().parent.parent / "frontend"
app.mount("/static", StaticFiles(directory=frontend), name="static")

@app.get("/")
async def index():
    return FileResponse(frontend / "index.html")

if __name__ == "__main__":
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run("app.main:app", host="0.0.0.0", port=port)
