import os
from dataclasses import dataclass
from dotenv import load_dotenv
load_dotenv()

def csv(v): return [x.strip() for x in (v or "").split(",") if x.strip()]

@dataclass(frozen=True)
class Settings:
    bot_token: str
    database_url: str
    webapp_url: str
    admin_ids: list[int]
    allowed_iframe_hosts: list[str]
    webapp_secret_ttl: int
    broadcast_delay: float

def load_settings():
    token=os.getenv("BOT_TOKEN","").strip()
    if not token: raise RuntimeError("BOT_TOKEN is required")
    return Settings(token, os.getenv("DATABASE_URL","sqlite+aiosqlite:///./data/app.db"),
        os.getenv("WEBAPP_URL","http://localhost:8000").rstrip("/"),
        [int(x) for x in csv(os.getenv("ADMIN_IDS",""))],
        [x.lower() for x in csv(os.getenv("ALLOWED_IFRAME_HOSTS",""))],
        int(os.getenv("WEBAPP_SECRET_TTL","86400")),
        float(os.getenv("BROADCAST_DELAY","0.08")))
settings=load_settings()
