from pathlib import Path
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import DeclarativeBase
from .config import settings
if settings.database_url.startswith("sqlite"): Path("data").mkdir(exist_ok=True)
engine=create_async_engine(settings.database_url, future=True)
SessionLocal=async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
class Base(DeclarativeBase): pass
async def init_db():
    from . import models
    async with engine.begin() as conn: await conn.run_sync(Base.metadata.create_all)
