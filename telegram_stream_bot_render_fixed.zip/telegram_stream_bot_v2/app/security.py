import hashlib,hmac,time,urllib.parse
from .config import settings
def validate_telegram_init_data(init_data):
    if not init_data: raise ValueError("Missing Telegram initData")
    data=dict(urllib.parse.parse_qsl(init_data,keep_blank_values=True))
    received=data.pop("hash",None)
    if not received: raise ValueError("Missing hash")
    if time.time()-int(data.get("auth_date","0"))>settings.webapp_secret_ttl: raise ValueError("Expired initData")
    check="\n".join(f"{k}={v}" for k,v in sorted(data.items()))
    secret=hmac.new(b"WebAppData",settings.bot_token.encode(),hashlib.sha256).digest()
    calc=hmac.new(secret,check.encode(),hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calc,received): raise ValueError("Invalid initData")
    return data
