from datetime import datetime, timezone
from sqlalchemy import String, Text, Boolean, Integer, DateTime, ForeignKey, BigInteger
from sqlalchemy.orm import Mapped, mapped_column
from .db import Base
def now(): return datetime.now(timezone.utc)

class User(Base):
    __tablename__="users"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    telegram_id:Mapped[int]=mapped_column(BigInteger,unique=True,index=True)
    username:Mapped[str|None]=mapped_column(String(255))
    first_name:Mapped[str|None]=mapped_column(String(255))
    blocked:Mapped[bool]=mapped_column(Boolean,default=False)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
    last_active:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class Admin(Base):
    __tablename__="admins"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    telegram_id:Mapped[int]=mapped_column(BigInteger,unique=True,index=True)
    role:Mapped[str]=mapped_column(String(32),default="admin")
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class Stream(Base):
    __tablename__="streams"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    title:Mapped[str]=mapped_column(String(255))
    description:Mapped[str|None]=mapped_column(Text)
    image_url:Mapped[str|None]=mapped_column(String(1000))
    iframe_code:Mapped[str]=mapped_column(Text)
    status:Mapped[str]=mapped_column(String(20),default="live")
    enabled:Mapped[bool]=mapped_column(Boolean,default=True)
    sort_order:Mapped[int]=mapped_column(Integer,default=0)
    views:Mapped[int]=mapped_column(Integer,default=0)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class RequiredChannel(Base):
    __tablename__="required_channels"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    chat_id:Mapped[int]=mapped_column(BigInteger,unique=True)
    title:Mapped[str]=mapped_column(String(255))
    invite_url:Mapped[str]=mapped_column(String(1000))
    enabled:Mapped[bool]=mapped_column(Boolean,default=True)

class View(Base):
    __tablename__="views"
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    stream_id:Mapped[int]=mapped_column(ForeignKey("streams.id"))
    telegram_id:Mapped[int]=mapped_column(BigInteger,index=True)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
