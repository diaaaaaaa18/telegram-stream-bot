# Telegram Stream Bot V2

بوت Telegram + Web App لإدارة بثوث متعددة من داخل البوت.

## المزايا
- إضافة/تعديل/حذف/تفعيل البثوث
- إدخال iframe مع فلترة النطاق
- Force Subscribe وإدارة القنوات
- إدارة الأدمن والصلاحيات
- Broadcast مع rate limiting
- إحصائيات
- Deep link: `?startapp=stream_ID`
- Telegram WebApp initData validation
- SQLite افتراضيًا

## التشغيل
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m app.main
```

وفي Terminal آخر:
```bash
python -m app.bot
```

ضع:
- `BOT_TOKEN`
- `WEBAPP_URL` (HTTPS في الإنتاج)
- `ADMIN_IDS` أول Super Admin
- `ALLOWED_IFRAME_HOSTS` اختياري لكنه موصى به

## ملاحظة قانونية وتقنية
استخدم فقط مصادر بث تملك حق عرضها. لا يتضمن المشروع أي تجاوز لحماية المواقع أو الوصول غير المصرح به. إذا كان الموقع يمنع iframe بواسطة CSP/X-Frame-Options فلن يحاول المشروع تجاوز ذلك.
