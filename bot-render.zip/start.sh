#!/bin/bash
echo "Starting Telegram Bot..."
node bot.js
