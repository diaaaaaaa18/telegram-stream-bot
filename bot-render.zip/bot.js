/**
 * ============================================================================
 * 🤖 بوت تيليجرام للبث المباشر والاشتراك الإجباري (CommonJS - يعمل على أي جهاز)
 * ============================================================================
 * 
 * ✅ متوافق 100% مع جميع إصدارات Node.js (14, 16, 18, 20, 22+)
 * ✅ لا يحتاج أي ملفات إضافية أو package.json
 * ✅ لا يحتاج تثبيت أي مكاتب عبر npm (يعتمد على مكاتب Node المدمجة)
 * 
 * 🚀 طريقة التشغيل:
 *    node bot.js
 * ============================================================================
 */

const fs = require("fs");
const path = require("path");
const https = require("https");
const http = require("http");

// ==================== سيرفر HTTP بسيط (خاص بـ Render فقط) ====================
// Render يتطلب أن يفتح المشروع بورت HTTP عشان يعتبره "شغال". مش له علاقة بعمل البوت نفسه.
// اربط رابط هذا السيرفر بخدمة UptimeRobot (كل 5-10 دقائق) عشان يمنع Render من تنويم الخدمة.
const HTTP_PORT = process.env.PORT || 3000;
http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
  res.end("Bot is alive ✅");
}).listen(HTTP_PORT, () => {
  console.log(`🌐 [Keep-Alive] سيرفر HTTP شغال على البورت ${HTTP_PORT}`);
});

// ======================== الإعدادات الأساسية ========================
const CONFIG = {
  // توكن البوت - لازم يتحط كمتغير بيئة TELEGRAM_BOT_TOKEN من لوحة تحكم Render (ما تحطوش هنا أبداً)
  botToken: process.env.TELEGRAM_BOT_TOKEN || "",
  
  // معرّف تيليجرام لصاحب البوت - لازم يتحط كمتغير بيئة ADMIN_ID من لوحة تحكم Render
  adminId: String(process.env.ADMIN_ID || process.env.ADMIN_CHAT_ID || ""),
  
  // رابط مشغل البث المباشر (Mini App) - لازم يتحط كمتغير بيئة APP_URL من لوحة تحكم Render
  appUrl: process.env.APP_URL || "",
  
  // مسار حفظ قاعدة البيانات المحلية
  dataFile: path.join(process.cwd(), "data", "db.json"),
  dataDir: path.join(process.cwd(), "data")
};

// ======================== قاعدة البيانات المحلية ========================
let db = {
  streams: [],
  channels: [],
  users: [],
  settings: {
    welcomeMessage: "أهلاً بك في بوت البث المباشر 📺✨\nيمكنك تشغيل البث المباشر ومتابعة المباريات عبر المشغل الداخلي!",
    adminWelcomeMessage: "👑 مرحباً بك يا صاحب البوت ({name})!\n\nتم التعرف على معرّفك التلجرامي ({id}) كمالك للبوت.\n⭐ زر لوحة التحكم يظهر لك أنت فقط دون بقية المشتركين:\n\n👇 اختر ما تريد القيام به:",
    forceSubEnabled: false,
    forceSubMessage: "⚠️ عذراً عزيزي!\nعليك الاشتراك في قنوات البوت أولاً لتتمكن من تشغيل البث واستخدام البوت:\n\n{channels}\n\nبعد الاشتراك اضغط على زر \"✅ تحقق من الاشتراك\" بالأسفل."
  }
};

// تحميل البيانات من الملف إن وُجد
function loadDatabase() {
  try {
    if (!fs.existsSync(CONFIG.dataDir)) {
      fs.mkdirSync(CONFIG.dataDir, { recursive: true });
    }
    if (fs.existsSync(CONFIG.dataFile)) {
      const raw = fs.readFileSync(CONFIG.dataFile, "utf-8");
      const loaded = JSON.parse(raw);
      db = Object.assign({}, db, loaded);
      if (!db.settings.adminWelcomeMessage) {
        db.settings.adminWelcomeMessage = "👑 مرحباً بك يا صاحب البوت ({name})!\n\nتم التعرف على معرّفك التلجرامي ({id}) كمالك للبوت.\n⭐ زر لوحة التحكم يظهر لك أنت فقط دون بقية المشتركين:\n\n👇 اختر ما تريد القيام به:";
      }
      console.log(`[DB] تم تحميل البيانات: ${db.users.length} مستخدم، ${db.streams.length} بث، ${db.channels.length} قناة`);
    } else {
      saveDatabase();
    }
  } catch (err) {
    console.error("[DB] خطأ في قراءة قاعدة البيانات:", err.message);
  }
}

function saveDatabase() {
  try {
    if (!fs.existsSync(CONFIG.dataDir)) {
      fs.mkdirSync(CONFIG.dataDir, { recursive: true });
    }
    fs.writeFileSync(CONFIG.dataFile, JSON.stringify(db, null, 2));
  } catch (err) {
    console.error("[DB] خطأ في حفظ البيانات:", err.message);
  }
}

// ======================== التفاعل مع Telegram API ========================
function callTelegram(method, payload) {
  payload = payload || {};
  if (!CONFIG.botToken) {
    console.warn("⚠️ تنبيه: يرجى ضبط TELEGRAM_BOT_TOKEN");
    return Promise.resolve(null);
  }

  if (typeof fetch === "function") {
    return fetch(`https://api.telegram.org/bot${CONFIG.botToken}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    })
      .then(res => res.json())
      .catch(err => {
        console.error(`[Telegram Error] ${method}:`, err.message);
        return null;
      });
  }

  return new Promise((resolve) => {
    const postData = JSON.stringify(payload);
    const options = {
      hostname: "api.telegram.org",
      port: 443,
      path: `/bot${CONFIG.botToken}/${method}`,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(postData)
      },
      timeout: 30000
    };

    const req = https.request(options, (res) => {
      let body = "";
      res.on("data", chunk => { body += chunk; });
      res.on("end", () => {
        try {
          resolve(JSON.parse(body));
        } catch {
          resolve(null);
        }
      });
    });

    req.on("error", (err) => {
      console.error(`[Telegram API Error] ${method}:`, err.message);
      resolve(null);
    });

    req.write(postData);
    req.end();
  });
}

// فحص اشتراك المستخدم في القناة
async function isUserSubscribedToChannel(userId, channelTarget) {
  try {
    let clean = (channelTarget || "").trim();
    if (!clean.startsWith("@") && !clean.startsWith("-100") && !clean.startsWith("-")) {
      clean = "@" + clean;
    }
    const res = await callTelegram("getChatMember", {
      chat_id: clean,
      user_id: userId
    });
    if (res && res.ok && res.result) {
      const status = res.result.status;
      return ["creator", "administrator", "member", "restricted"].includes(status);
    }
    return false;
  } catch {
    return false;
  }
}

// استخراج الرابط من كود الفريم أو النص
function extractSrcFromIframe(iframeOrUrl) {
  const trimmed = (iframeOrUrl || "").trim();
  const srcMatch = trimmed.match(/src=["']([^"']+)["']/i);
  if (srcMatch && srcMatch[1]) {
    return srcMatch[1];
  }
  if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
    return trimmed;
  }
  return "";
}

// ======================== معالجة التحديثات ========================
async function handleUpdate(update) {
  // 1. أزرار الشاشة (Callback Queries)
  if (update.callback_query) {
    const cb = update.callback_query;
    const chatId = (cb.message && cb.message.chat && cb.message.chat.id) || cb.from.id;
    const userId = cb.from.id;
    const data = cb.data;

    if (data === "verify_sub") {
      let allSubscribed = true;
      const unjoinedChannels = [];

      for (let i = 0; i < db.channels.length; i++) {
        const ch = db.channels[i];
        const isSub = await isUserSubscribedToChannel(userId, ch.username || ch.channelId || "");
        if (!isSub) {
          allSubscribed = false;
          unjoinedChannels.push(ch);
        }
      }

      if (allSubscribed || db.channels.length === 0) {
        await callTelegram("answerCallbackQuery", {
          callback_query_id: cb.id,
          text: "🎉 رائع! تم التحقق من اشتراكك بنجاح."
        });
        await callTelegram("sendMessage", {
          chat_id: chatId,
          text: `✅ تم التحقق من اشتراكك بنجاح!\n\n👇 اضغط على الزر أدناه لفتح مشغل البث المباشر:`,
          reply_markup: {
            inline_keyboard: [
              [
                {
                  text: "📺 فتح مشغل البث المباشر (Mini App)",
                  web_app: { url: `${CONFIG.appUrl}?tgUser=${userId}` }
                }
              ]
            ]
          }
        });
      } else {
        await callTelegram("answerCallbackQuery", {
          callback_query_id: cb.id,
          text: "❌ لم تشترك في جميع القنوات بعد! يرجى الاشتراك في جميع القنوات ثم المحاولة مجدداً.",
          show_alert: true
        });
      }
      return;
    }

    await callTelegram("answerCallbackQuery", { callback_query_id: cb.id });
    return;
  }

  // 2. الرسائل النصية
  if (!update.message || !update.message.text) return;

  const msg = update.message;
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  const text = msg.text.trim();
  const firstName = msg.from.first_name || "مستخدم";
  const username = msg.from.username ? `@${msg.from.username}` : "بدون معرّف";
  const isSenderAdmin = userId === CONFIG.adminId;

  // تسجيل المستخدم
  let userIndex = db.users.findIndex(u => String(u.telegramId) === userId);
  if (userIndex === -1) {
    const newUser = {
      id: `user_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      telegramId: userId,
      firstName: firstName,
      username: username,
      joinedAt: new Date().toISOString(),
      lastActive: new Date().toISOString(),
      isSubscribed: true,
      totalStreamsWatched: 0
    };
    db.users.push(newUser);
    saveDatabase();

    if (!isSenderAdmin) {
      await callTelegram("sendMessage", {
        chat_id: CONFIG.adminId,
        text: `🔔 *عضو جديد انضم للبوت!*\n\n` +
              `👤 *الاسم:* ${firstName}\n` +
              `🔗 *المعرّف:* ${username}\n` +
              `🆔 *الآيدي (ID):* \`${userId}\`\n\n` +
              `👥 *إجمالي المشتركين:* ${db.users.length}`,
        parse_mode: "Markdown"
      });
    }
  } else {
    db.users[userIndex].lastActive = new Date().toISOString();
    db.users[userIndex].firstName = firstName;
    db.users[userIndex].username = username;
    saveDatabase();
  }

  // فحص الاشتراك الإجباري
  if (!isSenderAdmin && db.settings.forceSubEnabled && db.channels.length > 0) {
    let unjoined = [];
    for (let i = 0; i < db.channels.length; i++) {
      const ch = db.channels[i];
      const isSub = await isUserSubscribedToChannel(userId, ch.username || ch.channelId || "");
      if (!isSub) unjoined.push(ch);
    }

    if (unjoined.length > 0) {
      const channelButtons = unjoined.map(ch => [
        { text: `📢 اشترك في: ${ch.title || ch.username}`, url: ch.inviteLink || `https://t.me/${(ch.username || "").replace('@', '')}` }
      ]);
      channelButtons.push([{ text: "✅ تحقق من الاشتراك", callback_data: "verify_sub" }]);

      await callTelegram("sendMessage", {
        chat_id: chatId,
        text: db.settings.forceSubMessage.replace("{channels}", unjoined.map(c => `• ${c.title || c.username}: https://t.me/${(c.username || "").replace('@', '')}`).join("\n")),
        reply_markup: { inline_keyboard: channelButtons }
      });
      return;
    }
  }

  // أمر /start
  if (text === "/start" || text.startsWith("/start ")) {
    if (isSenderAdmin) {
      let adminText = db.settings.adminWelcomeMessage || 
        `👑 *مرحباً بك يا صاحب البوت ({name})!*\n\n` +
        `تم التعرف على معرّفك التلجرامي (\`{id}\`) كمالك للبوت.\n` +
        `⭐ *زر لوحة التحكم يظهر لك أنت فقط دون بقية المشتركين*:\n\n` +
        `👇 اختر ما تريد القيام به:`;
      adminText = adminText.replace(/\{name\}/g, firstName);
      adminText = adminText.replace(/\{id\}/g, String(chatId));

      await callTelegram("sendMessage", {
        chat_id: chatId,
        text: adminText,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "⚙️ لوحة تحكم صاحب البوت (خاصة بك فقط)",
                web_app: { url: `${CONFIG.appUrl}?tgUser=${chatId}&view=admin` }
              }
            ],
            [
              {
                text: "📺 فتح مشغل البث المباشر (Mini App)",
                web_app: { url: `${CONFIG.appUrl}?tgUser=${chatId}` }
              }
            ]
          ]
        }
      });
      return;
    }

    // للمشتركين العاديين
    await callTelegram("sendMessage", {
      chat_id: chatId,
      text: `${db.settings.welcomeMessage}\n\n👇 اضغط بالأسفل لفتح مشغل البث المباشر (Mini App):`,
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "📺 فتح مشغل البث المباشر (Mini App)",
              web_app: { url: `${CONFIG.appUrl}?tgUser=${chatId}` }
            }
          ]
        ]
      }
    });
    return;
  }

  // أوامر الأدمن
  if (isSenderAdmin) {
    // إحصائيات
    if (text === "/stats" || text === "/احصائيات") {
      const activeCount = db.streams.filter(s => s.isActive).length;
      await callTelegram("sendMessage", {
        chat_id: chatId,
        text: `📊 *إحصائيات البوت:*\n\n` +
              `👥 عدد المشتركين: *${db.users.length}*\n` +
              `📺 القنوات المتاحة: *${activeCount}* من أصل *${db.streams.length}*\n` +
              `📢 قنوات الاشتراك الإجباري: *${db.channels.length}*\n` +
              `🛡️ نظام الاشتراك الإجباري: *${db.settings.forceSubEnabled ? "مفعل ✅" : "معطل ❌"}*`,
        parse_mode: "Markdown"
      });
      return;
    }

    // عرض القنوات
    if (text === "/channels" || text === "/قنوات") {
      if (db.channels.length === 0) {
        await callTelegram("sendMessage", {
          chat_id: chatId,
          text: `📢 لا توجد قنوات اشتراك إجباري حالياً.\n➕ للإضافة: \`/addchannel @username اسم القناة\``,
          parse_mode: "Markdown"
        });
        return;
      }
      const list = db.channels.map((c, i) => `${i + 1}. *${c.title}* (${c.username})`).join("\n");
      await callTelegram("sendMessage", {
        chat_id: chatId,
        text: `📢 *قنوات الاشتراك الإجباري:*\n\n${list}\n\n🗑️ للحذف: \`/delchannel @username\``,
        parse_mode: "Markdown"
      });
      return;
    }

    // إضافة قناة
    if (text.startsWith("/addchannel")) {
      const parts = text.split(" ");
      const chUser = parts[1];
      const chTitle = parts.slice(2).join(" ") || chUser;
      if (!chUser || !chUser.startsWith("@")) {
        await callTelegram("sendMessage", {
          chat_id: chatId,
          text: `⚠️ الاستخدام: \`/addchannel @username اسم القناة\``,
          parse_mode: "Markdown"
        });
        return;
      }
      db.channels.push({
        id: `ch_${Date.now()}`,
        title: chTitle,
        username: chUser,
        inviteLink: `https://t.me/${chUser.replace('@', '')}`,
        isRequired: true,
        addedAt: new Date().toISOString()
      });
      saveDatabase();
      await callTelegram("sendMessage", {
        chat_id: chatId,
        text: `✅ تمت إضافة القناة *${chTitle}* (${chUser}) بنجاح!`,
        parse_mode: "Markdown"
      });
      return;
    }

    // حذف قناة
    if (text.startsWith("/delchannel")) {
      const chUser = text.split(" ")[1];
      if (!chUser) {
        await callTelegram("sendMessage", {
          chat_id: chatId,
          text: `⚠️ الاستخدام: \`/delchannel @username\``,
          parse_mode: "Markdown"
        });
        return;
      }
      const before = db.channels.length;
      db.channels = db.channels.filter(c => (c.username || "").toLowerCase() !== chUser.toLowerCase());
      saveDatabase();
      await callTelegram("sendMessage", {
        chat_id: chatId,
        text: db.channels.length < before ? `🗑️ تم حذف ${chUser}` : `❌ لم يتم العثور على القناة`
      });
      return;
    }

    // إذاعة
    if (text.startsWith("/broadcast") || text.startsWith("/اذاعة") || text.startsWith("/نشر")) {
      const broadcastText = text.replace(/^\/(broadcast|اذاعة|نشر)\s*/, "").trim();
      if (!broadcastText) {
        await callTelegram("sendMessage", {
          chat_id: chatId,
          text: `⚠️ اكتب نص الإذاعة بعد الأمر: \`/اذاعة السلام عليكم...\``,
          parse_mode: "Markdown"
        });
        return;
      }

      await callTelegram("sendMessage", {
        chat_id: chatId,
        text: `⏳ *بدء إرسال الإذاعة إلى ${db.users.length} مشترك...*`,
        parse_mode: "Markdown"
      });

      let sent = 0;
      let failed = 0;

      for (let i = 0; i < db.users.length; i++) {
        const u = db.users[i];
        try {
          const res = await callTelegram("sendMessage", {
            chat_id: u.telegramId,
            text: `${broadcastText}\n\n👇 اضغط بالأسفل لفتح المشغل:`,
            reply_markup: {
              inline_keyboard: [
                [
                  {
                    text: "📺 مشاهدة البث المباشر (Mini App)",
                    web_app: { url: `${CONFIG.appUrl}?tgUser=${u.telegramId}` }
                  }
                ]
              ]
            }
          });
          if (res && res.ok) sent++; else failed++;
          await new Promise(r => setTimeout(r, 50));
        } catch {
          failed++;
        }
      }

      await callTelegram("sendMessage", {
        chat_id: chatId,
        text: `✅ *اكتملت الإذاعة!*\n\n📨 وصل إلى: *${sent}*\n❌ تعذر: *${failed}*`,
        parse_mode: "Markdown"
      });
      return;
    }

    // إضافة بث مباشر (رابط أو كود فريم أو IPTV .m3u8)
    const isStreamInput = 
      text.includes("<iframe") || 
      text.includes("iframe") || 
      text.includes(".m3u8") || 
      text.includes("/iptv/") ||
      text.includes("player.twitch.tv") || 
      text.includes("youtube.com/embed") ||
      text.startsWith("http://") || 
      text.startsWith("https://");

    if (isStreamInput) {
      const extractedUrl = extractSrcFromIframe(text);
      const isHls = text.includes(".m3u8") || text.includes("/iptv/") || extractedUrl.includes(".m3u8");
      
      const newStream = {
        id: `stream_${Date.now()}`,
        title: isHls ? `بث مباشر IPTV #${db.streams.length + 1}` : `بث مباشر #${db.streams.length + 1}`,
        iframeCode: text.includes("<iframe") ? text : `<iframe src="${extractedUrl}" allowfullscreen></iframe>`,
        extractedUrl: extractedUrl,
        category: isHls ? "سيرفرات IPTV" : "بث المشرف",
        addedBy: "صاحب البوت",
        createdAt: new Date().toISOString(),
        views: 0,
        isActive: true,
        aspectRatio: "16:9",
        streamType: isHls ? "hls" : "iframe"
      };
      db.streams.unshift(newStream);
      saveDatabase();

      await callTelegram("sendMessage", {
        chat_id: chatId,
        text: `🎉 *تمت إضافة البث المباشر بنجاح!* ${isHls ? "📡 (IPTV)" : "📺"}\n\n` +
              `🏷️ *الاسم:* ${newStream.title}\n` +
              `🔗 *الرابط:* \`${extractedUrl || 'كود فريم'}\`\n\n` +
              `أصبح متاحاً الآن فوراً داخل المشغل لجميع المشتركين!`,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "📺 فتح المشغل ومعاينة البث",
                web_app: { url: `${CONFIG.appUrl}?tgUser=${chatId}` }
              }
            ]
          ]
        }
      });
      return;
    }
  }

  // رسالة افتراضية
  if (!isSenderAdmin) {
    await callTelegram("sendMessage", {
      chat_id: chatId,
      text: `${db.settings.welcomeMessage}\n\n👇 اضغط بالأسفل لفتح المشغل:`,
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "📺 فتح مشغل البث المباشر (Mini App)",
              web_app: { url: `${CONFIG.appUrl}?tgUser=${chatId}` }
            }
          ]
        ]
      }
    });
  }
}

// ======================== محرك Long-Polling ========================
let lastUpdateId = 0;

async function pollUpdates() {
  try {
    const res = await callTelegram("getUpdates", {
      offset: lastUpdateId + 1,
      timeout: 25,
      allowed_updates: ["message", "callback_query"]
    });

    if (res && res.ok && Array.isArray(res.result)) {
      for (let i = 0; i < res.result.length; i++) {
        const update = res.result[i];
        lastUpdateId = update.update_id;
        await handleUpdate(update).catch(err => console.error("[Update Err]:", err));
      }
    }
  } catch (err) {
    console.error("[Polling Err]:", err.message);
    await new Promise(r => setTimeout(r, 3000));
  }
}

// تشغيل البوت
async function startBot() {
  if (!CONFIG.botToken || !CONFIG.adminId) {
    console.error("❌ خطأ: لازم تضبط متغيرات البيئة TELEGRAM_BOT_TOKEN و ADMIN_ID قبل التشغيل.");
    console.error("   في Render: Environment > Add Environment Variable");
    process.exit(1);
  }
  console.log("==========================================");
  console.log("🚀 جاري بدء تشغيل بوت البث المباشر (Standalone)...");
  console.log(`👑 آيدي الأدمن: ${CONFIG.adminId}`);
  console.log(`🌐 رابط المشغل: ${CONFIG.appUrl}`);
  console.log("==========================================");

  loadDatabase();

  const me = await callTelegram("getMe");
  if (me && me.ok) {
    console.log(`✅ تم الاتصال بنجاح بالبوت: @${me.result.username} (${me.result.first_name})`);
    console.log("🟢 البوت يعمل الآن ويستقبل الرسائل والأوامر...");
  } else {
    console.warn("⚠️ تنبيه: تعذر الاتصال بـ Telegram، تحقق من التوكن والإنترنت");
  }

  while (true) {
    await pollUpdates();
  }
}

startBot();
