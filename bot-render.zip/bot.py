#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
============================================================================
🤖 بوت تيليجرام للبث المباشر والاشتراك الإجباري (نسخة بايثون Python المستقلة)
============================================================================
✅ يعمل مباشرة بـ Python 3 بدون الحاجة لتثبيت أي مكاتب خارجية (بدون pip).
✅ يعتمد فقط على مكتبات بايثون القياسية (urllib, json, time, os).

🚀 طريقة التشغيل:
    python bot.py
    أو:
    python3 bot.py
============================================================================
"""

import os
import json
import time
import urllib.request
import urllib.parse
import re

# الإعدادات
BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "8992737270:AAFl01WbEjfZbODD5b2DtAmgomP6L2R94nI")
ADMIN_ID = str(os.environ.get("ADMIN_ID", "1811882922"))
APP_URL = os.environ.get("APP_URL", "https://ais-pre-6wzbaok42v5ny6oeuu64n7-234699217927.europe-west2.run.app")

DATA_DIR = os.path.join(os.getcwd(), "data")
DATA_FILE = os.path.join(DATA_DIR, "db.json")

# قاعدة البيانات
db = {
    "streams": [],
    "channels": [],
    "users": [],
    "settings": {
        "welcomeMessage": "أهلاً بك في بوت البث المباشر 📺✨\nيمكنك تشغيل البث المباشر ومتابعة المباريات عبر المشغل الداخلي!",
        "adminWelcomeMessage": "👑 مرحباً بك يا صاحب البوت ({name})!\n\nتم التعرف على معرّفك ({id}) كمالك للبوت.\n⭐ زر لوحة التحكم يظهر لك أنت فقط دون بقية المشتركين:\n\n👇 اختر ما تريد القيام به:",
        "forceSubEnabled": False,
        "forceSubMessage": "⚠️ عذراً عزيزي!\nعليك الاشتراك في قنوات البوت أولاً:\n\n{channels}\n\nبعد الاشتراك اضغط على زر \"✅ تحقق من الاشتراك\"."
    }
}

def load_db():
    global db
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                loaded = json.load(f)
                db.update(loaded)
            print(f"[DB] تم تحميل البيانات: {len(db['users'])} مستخدم، {len(db['streams'])} بث، {len(db['channels'])} قناة")
        else:
            save_db()
    except Exception as e:
        print("[DB Error]:", e)

def save_db():
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(db, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print("[Save DB Error]:", e)

def call_telegram(method, payload=None):
    if not BOT_TOKEN:
        print("⚠️ يرجى ضبط TELEGRAM_BOT_TOKEN")
        return None
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/{method}"
    data = json.dumps(payload or {}).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception as e:
        print(f"[Telegram API Err] {method}:", e)
        return None

def is_subscribed(user_id, channel_target):
    try:
        target = (channel_target or "").strip()
        if not target.startswith("@") and not target.startswith("-100") and not target.startswith("-"):
            target = "@" + target
        res = call_telegram("getChatMember", {"chat_id": target, "user_id": user_id})
        if res and res.get("ok") and res.get("result"):
            status = res["result"].get("status")
            return status in ["creator", "administrator", "member", "restricted"]
        return False
    except:
        return False

def extract_iframe_url(text):
    text = (text or "").strip()
    match = re.search(r'src=["\']([^"\']+)["\']', text, re.IGNORECASE)
    if match:
        return match.group(1)
    if text.startswith("http://") or text.startswith("https://"):
        return text
    return ""

def handle_update(update):
    # 1. كولباك
    if "callback_query" in update:
        cb = update["callback_query"]
        cb_id = cb["id"]
        chat_id = cb.get("message", {}).get("chat", {}).get("id") or cb["from"]["id"]
        user_id = cb["from"]["id"]
        data = cb.get("data", "")

        if data == "verify_sub":
            unjoined = [ch for ch in db["channels"] if not is_subscribed(user_id, ch.get("username") or ch.get("channelId"))]
            if not unjoined or not db["channels"]:
                call_telegram("answerCallbackQuery", {"callback_query_id": cb_id, "text": "🎉 تم التحقق بنجاح!"})
                call_telegram("sendMessage", {
                    "chat_id": chat_id,
                    "text": "✅ تم التحقق من اشتراكك بنجاح!\n\n👇 اضغط لفتح المشغل:",
                    "reply_markup": {
                        "inline_keyboard": [[
                            {"text": "📺 فتح مشغل البث المباشر (Mini App)", "web_app": {"url": f"{APP_URL}?tgUser={user_id}"}}
                        ]]
                    }
                })
            else:
                call_telegram("answerCallbackQuery", {
                    "callback_query_id": cb_id,
                    "text": "❌ لم تشترك في جميع القنوات بعد!",
                    "show_alert": True
                })
            return

        call_telegram("answerCallbackQuery", {"callback_query_id": cb_id})
        return

    # 2. رسالة
    if "message" not in update or "text" not in update["message"]:
        return

    msg = update["message"]
    chat_id = msg["chat"]["id"]
    user_id = str(msg["from"]["id"])
    text = msg["text"].strip()
    first_name = msg["from"].get("first_name", "مستخدم")
    username = f"@{msg['from']['username']}" if "username" in msg["from"] else "بدون معرّف"
    is_admin = (user_id == ADMIN_ID)

    # تسجيل العضو
    user_exists = False
    for u in db["users"]:
        if str(u.get("telegramId")) == user_id:
            user_exists = True
            u["lastActive"] = time.strftime("%Y-%m-%dT%H:%M:%SZ")
            u["firstName"] = first_name
            u["username"] = username
            save_db()
            break

    if not user_exists:
        new_u = {
            "id": f"user_{int(time.time()*1000)}",
            "telegramId": user_id,
            "firstName": first_name,
            "username": username,
            "joinedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "lastActive": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "isSubscribed": True,
            "totalStreamsWatched": 0
        }
        db["users"].append(new_u)
        save_db()

        if not is_admin:
            call_telegram("sendMessage", {
                "chat_id": ADMIN_ID,
                "text": f"🔔 *عضو جديد انضم للبوت!*\n\n👤 *الاسم:* {first_name}\n🔗 *المعرّف:* {username}\n🆔 *الآيدي:* `{user_id}`\n\n👥 *المشتركين:* {len(db['users'])}",
                "parse_mode": "Markdown"
            })

    # فحص الاشتراك الإجباري
    if not is_admin and db["settings"].get("forceSubEnabled") and db["channels"]:
        unjoined = [ch for ch in db["channels"] if not is_subscribed(user_id, ch.get("username") or ch.get("channelId"))]
        if unjoined:
            kb = []
            for ch in unjoined:
                u_name = (ch.get("username") or "").replace("@", "")
                kb.append([{"text": f"📢 اشترك في: {ch.get('title') or ch.get('username')}", "url": ch.get("inviteLink") or f"https://t.me/{u_name}"}])
            kb.append([{"text": "✅ تحقق من الاشتراك", "callback_data": "verify_sub"}])

            call_telegram("sendMessage", {
                "chat_id": chat_id,
                "text": db["settings"].get("forceSubMessage", "اشترك أولاً في القنوات").replace("{channels}", "\n".join([f"• {c.get('title')}: https://t.me/{c.get('username','').replace('@','')}" for c in unjoined])),
                "reply_markup": {"inline_keyboard": kb}
            })
            return

    # أوامر /start
    if text == "/start" or text.startswith("/start "):
        if is_admin:
            admin_msg = db["settings"].get("adminWelcomeMessage", "👑 مرحباً بك يا صاحب البوت!")
            admin_msg = admin_msg.replace("{name}", first_name).replace("{id}", str(chat_id))
            call_telegram("sendMessage", {
                "chat_id": chat_id,
                "text": admin_msg,
                "parse_mode": "Markdown",
                "reply_markup": {
                    "inline_keyboard": [
                        [{"text": "⚙️ لوحة تحكم صاحب البوت", "web_app": {"url": f"{APP_URL}?tgUser={chat_id}&view=admin"}}],
                        [{"text": "📺 فتح المشغل المباشر (Mini App)", "web_app": {"url": f"{APP_URL}?tgUser={chat_id}"}}]
                    ]
                }
            })
            return

        call_telegram("sendMessage", {
            "chat_id": chat_id,
            "text": db["settings"].get("welcomeMessage", "أهلاً بك! اضغط بالأسفل للمشاهدة:"),
            "reply_markup": {
                "inline_keyboard": [
                    [{"text": "📺 فتح مشغل البث المباشر (Mini App)", "web_app": {"url": f"{APP_URL}?tgUser={chat_id}"}}]
                ]
            }
        })
        return

    # أوامر الأدمن
    if is_admin:
        if text in ["/stats", "/احصائيات"]:
            active = len([s for s in db["streams"] if s.get("isActive")])
            call_telegram("sendMessage", {
                "chat_id": chat_id,
                "text": f"📊 *إحصائيات البوت:*\n\n👥 المشتركين: *{len(db['users'])}*\n📺 القنوات: *{active}/{len(db['streams'])}*\n📢 قنوات الإجباري: *{len(db['channels'])}*",
                "parse_mode": "Markdown"
            })
            return

        if text.startswith("/broadcast") or text.startswith("/اذاعة") or text.startswith("/نشر"):
            b_text = re.sub(r"^/(broadcast|اذاعة|نشر)\s*", "", text).strip()
            if not b_text:
                call_telegram("sendMessage", {"chat_id": chat_id, "text": "⚠️ اكتب نص الإذاعة: `/اذاعة السلام عليكم`", "parse_mode": "Markdown"})
                return
            call_telegram("sendMessage", {"chat_id": chat_id, "text": f"⏳ جاري النشر إلى {len(db['users'])} مشترك..."})
            sent = 0
            for u in db["users"]:
                try:
                    res = call_telegram("sendMessage", {
                        "chat_id": u.get("telegramId"),
                        "text": f"{b_text}\n\n👇 اضغط للمشاهدة:",
                        "reply_markup": {"inline_keyboard": [[{"text": "📺 فتح المشغل", "web_app": {"url": f"{APP_URL}?tgUser={u.get('telegramId')}"}}]]}
                    })
                    if res and res.get("ok"): sent += 1
                    time.sleep(0.05)
                except:
                    pass
            call_telegram("sendMessage", {"chat_id": chat_id, "text": f"✅ اكتملت الإذاعة!\nوصلت إلى: {sent} مستخدم."})
            return

        # إضافة بث مباشر
        is_stream = ("<iframe" in text or "iframe" in text or ".m3u8" in text or "/iptv/" in text or text.startswith("http://") or text.startswith("https://"))
        if is_stream:
            url = extract_iframe_url(text)
            is_hls = (".m3u8" in text or "/iptv/" in text or ".m3u8" in url)
            new_s = {
                "id": f"stream_{int(time.time()*1000)}",
                "title": f"بث مباشر IPTV #{len(db['streams'])+1}" if is_hls else f"بث مباشر #{len(db['streams'])+1}",
                "iframeCode": text if "<iframe" in text else f'<iframe src="{url}" allowfullscreen></iframe>',
                "extractedUrl": url,
                "category": "سيرفرات IPTV" if is_hls else "بث المشرف",
                "addedBy": "صاحب البوت",
                "createdAt": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "views": 0,
                "isActive": True,
                "aspectRatio": "16:9",
                "streamType": "hls" if is_hls else "iframe"
            }
            db["streams"].insert(0, new_s)
            save_db()
            call_telegram("sendMessage", {
                "chat_id": chat_id,
                "text": f"🎉 *تمت إضافة البث بنجاح!*\n\n🏷️ *الاسم:* {new_s['title']}\n🔗 *الرابط:* `{url}`",
                "parse_mode": "Markdown",
                "reply_markup": {
                    "inline_keyboard": [[{"text": "📺 فتح المشغل", "web_app": {"url": f"{APP_URL}?tgUser={chat_id}"}}]]
                }
            })
            return

    # رد افتراضي للمشتركين
    if not is_admin:
        call_telegram("sendMessage", {
            "chat_id": chat_id,
            "text": db["settings"].get("welcomeMessage", "أهلاً بك! اضغط بالأسفل للمشاهدة:"),
            "reply_markup": {
                "inline_keyboard": [
                    [{"text": "📺 فتح مشغل البث المباشر (Mini App)", "web_app": {"url": f"{APP_URL}?tgUser={chat_id}"}}]
                ]
            }
        })

def main():
    print("=" * 45)
    print("🚀 جاري بدء تشغيل بوت التيليجرام (Python)...")
    print(f"👑 آيدي الأدمن: {ADMIN_ID}")
    print(f"🌐 رابط المشغل: {APP_URL}")
    print("=" * 45)

    load_db()

    me = call_telegram("getMe")
    if me and me.get("ok"):
        print(f"✅ تم الاتصال بنجاح بالبوت: @{me['result'].get('username')}")
        print("🟢 البوت يعمل الآن ويستقبل الرسائل والأوامر...")
    else:
        print("⚠️ تعذر الاتصال بـ Telegram، تحقق من التوكن")

    last_update_id = 0
    while True:
        try:
            res = call_telegram("getUpdates", {"offset": last_update_id + 1, "timeout": 25, "allowed_updates": ["message", "callback_query"]})
            if res and res.get("ok") and isinstance(res.get("result"), list):
                for update in res["result"]:
                    last_update_id = update["update_id"]
                    try:
                        handle_update(update)
                    except Exception as err:
                        print("[Update Err]:", err)
        except Exception as e:
            print("[Polling Err]:", e)
            time.sleep(3)

if __name__ == "__main__":
    main()
