@echo off
title Telegram Live Stream Bot
echo ===========================================
echo Telegram Stream Bot
echo ===========================================
node bot.js
pause
