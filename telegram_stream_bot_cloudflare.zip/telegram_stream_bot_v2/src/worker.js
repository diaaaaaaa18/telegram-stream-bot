const json = (data, status=200) => new Response(JSON.stringify(data), {status, headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});
const html = (text, status=200) => new Response(text,{status,headers:{"content-type":"text/html; charset=utf-8"}});

function envList(v){ return String(v||"").split(",").map(x=>x.trim().toLowerCase()).filter(Boolean); }
function adminIds(env){ return String(env.ADMIN_IDS||"").split(",").map(x=>Number(x.trim())).filter(Number.isFinite); }
function isSuper(env, id){ return adminIds(env).includes(Number(id)); }
async function isAdmin(env,id){
  if(isSuper(env,id)) return true;
  const r=await env.DB.prepare("SELECT 1 FROM admins WHERE telegram_id=? LIMIT 1").bind(Number(id)).first();
  return !!r;
}
async function isSuperDb(env,id){ return isSuper(env,id); }

async function tg(env, method, body={}){
  const r=await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/${method}`,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(body)});
  const d=await r.json();
  if(!d.ok) throw new Error(d.description||"Telegram API error");
  return d.result;
}

async function ensureUser(env,u){
  await env.DB.prepare(`INSERT INTO users(telegram_id,username,first_name) VALUES(?,?,?)
    ON CONFLICT(telegram_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name, last_active=datetime('now')`)
    .bind(Number(u.id),u.username||null,u.first_name||null).run();
}
async function channels(env){ return (await env.DB.prepare("SELECT * FROM required_channels WHERE enabled=1 ORDER BY id").all()).results||[]; }
async function subscribed(env,uid){
  for(const c of await channels(env)){
    try{
      const m=await tg(env,"getChatMember",{chat_id:Number(c.chat_id),user_id:Number(uid)});
      if(["left","kicked"].includes(m.status)) return false;
    }catch(_){ return false; }
  }
  return true;
}
function webAppButton(env,text="📺 مشاهدة البثوث"){ return {text,web_app:{url:env.WEBAPP_URL}}; }
function adminKeyboard(env){ return {inline_keyboard:[
  [{text:"📺 إدارة البثوث",callback_data:"adm_streams"}],
  [{text:"📢 القنوات الإجبارية",callback_data:"adm_channels"}],
  [{text:"👨‍💻 إدارة الأدمن",callback_data:"adm_admins"}],
  [{text:"📣 إذاعة",callback_data:"adm_broadcast"}],
  [{text:"📊 الإحصائيات",callback_data:"adm_stats"}],
  [webAppButton(env,"🔗 فتح التطبيق")]
]}; }
async function send(env,chat_id,text,extra={}){ return tg(env,"sendMessage",{chat_id,text,...extra}); }

function sanitizeIframe(code, env){
  const s=String(code||"").trim();
  const m=s.match(/^<iframe\b([^>]*)>.*?<\/iframe>$/is);
  if(!m) throw new Error("أرسل كود iframe كاملًا.");
  const sm=m[1].match(/\bsrc\s*=\s*["']([^"']+)["']/i);
  if(!sm) throw new Error("iframe يجب أن يحتوي على src.");
  let u; try{ u=new URL(sm[1].trim()); }catch(_){ throw new Error("رابط iframe غير صالح."); }
  if(!["http:","https:"].includes(u.protocol)) throw new Error("رابط iframe غير صالح.");
  const host=u.hostname.toLowerCase(), allowed=envList(env.ALLOWED_IFRAME_HOSTS);
  if(allowed.length && !allowed.some(h=>host===h || host.endsWith("."+h))) throw new Error("النطاق غير مسموح.");
  const esc=u.toString().replace(/&/g,"&amp;").replace(/"/g,"&quot;");
  return `<iframe src="${esc}" style="width:100%;height:100%;border:0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen loading="lazy" referrerpolicy="no-referrer"></iframe>`;
}

function validateInitData(initData, env){
  if(!initData) throw new Error("افتح التطبيق من داخل Telegram");
  const p=new URLSearchParams(initData), received=p.get("hash"); if(!received) throw new Error("Missing hash");
  const authDate=Number(p.get("auth_date")||0), ttl=Number(env.WEBAPP_SECRET_TTL||86400);
  if(!authDate || Math.floor(Date.now()/1000)-authDate>ttl) throw new Error("Expired initData");
  p.delete("hash");
  const pairs=[...p.entries()].sort((a,b)=>a[0].localeCompare(b[0])).map(([k,v])=>`${k}=${v}`).join("\n");
  return crypto.subtle.importKey("raw",new TextEncoder().encode("WebAppData"),{name:"HMAC",hash:"SHA-256"},false,["sign"])
    .then(key=>crypto.subtle.sign("HMAC",key,new TextEncoder().encode(env.BOT_TOKEN)))
    .then(async secretBuf=>{
      const secret=await crypto.subtle.importKey("raw",secretBuf,{name:"HMAC",hash:"SHA-256"},false,["sign"]);
      const sig=await crypto.subtle.sign("HMAC",secret,new TextEncoder().encode(pairs));
      const hex=[...new Uint8Array(sig)].map(b=>b.toString(16).padStart(2,"0")).join("");
      if(hex!==received) throw new Error("Invalid initData");
      const user=JSON.parse(p.get("user")||"{}"); return {id:Number(user.id),user};
    });
}
async function auth(req,env){
  const d=req.headers.get("X-Telegram-Init-Data"); if(!d) throw new Error("افتح التطبيق من داخل Telegram");
  return validateInitData(d,env);
}

async function api(req,env,url){
  let a; try{a=await auth(req,env);}catch(e){return json({detail:e.message},401)}
  const path=url.pathname;
  if(req.method==="POST" && path==="/api/session"){
    await ensureUser(env,a.user); return json({ok:true,user_id:a.id,admin:await isAdmin(env,a.id)});
  }
  if(req.method==="GET" && path==="/api/streams"){
    const q=url.searchParams.get("q")||"";
    const sql=q.trim()?"SELECT id,title,description,image_url,status,views,enabled FROM streams WHERE enabled=1 AND title LIKE ? ORDER BY sort_order,id DESC":"SELECT id,title,description,image_url,status,views,enabled FROM streams WHERE enabled=1 ORDER BY sort_order,id DESC";
    const r=q.trim()?await env.DB.prepare(sql).bind(`%${q.trim()}%`).all():await env.DB.prepare(sql).all();
    return json(r.results||[]);
  }
  const sm=path.match(/^\/api\/streams\/(\d+)$/);
  if(req.method==="GET" && sm){
    const id=Number(sm[1]), x=await env.DB.prepare("SELECT * FROM streams WHERE id=? AND enabled=1").bind(id).first();
    if(!x) return json({detail:"البث غير موجود"},404);
    await env.DB.prepare("UPDATE streams SET views=views+1 WHERE id=?").bind(id).run();
    await env.DB.prepare("INSERT INTO views(stream_id,telegram_id) VALUES(?,?)").bind(id,a.id).run();
    x.views=Number(x.views||0)+1; return json({id:x.id,title:x.title,description:x.description,image_url:x.image_url,status:x.status,views:x.views,iframe:x.iframe_code});
  }
  if(path==="/api/admin/streams-list" && req.method==="GET"){ if(!(await isAdmin(env,a.id))) return json({detail:"Admin only"},403); const r=await env.DB.prepare("SELECT id,title,description,image_url,status,views,enabled FROM streams ORDER BY sort_order,id DESC").all(); return json(r.results||[]); }
  if(path.startsWith("/api/admin/")){
    if(!(await isAdmin(env,a.id))) return json({detail:"Admin only"},403);
    if(req.method==="GET" && path==="/api/admin/dashboard"){
      const [u,s,v,ac]=await Promise.all([
        env.DB.prepare("SELECT COUNT(*) n FROM users").first(),env.DB.prepare("SELECT COUNT(*) n FROM streams").first(),env.DB.prepare("SELECT COUNT(*) n FROM views").first(),env.DB.prepare("SELECT COUNT(*) n FROM users WHERE last_active >= datetime('now','-1 day')").first()]);
      return json({users:u?.n||0,streams:s?.n||0,views:v?.n||0,active_24h:ac?.n||0});
    }
    const create=path==="/api/admin/streams";
    const edit=path.match(/^\/api\/admin\/streams\/(\d+)$/);
    if(create && req.method==="POST"){
      const p=await req.json(); let iframe; try{iframe=sanitizeIframe(p.iframe_code,env)}catch(e){return json({detail:e.message},400)}
      const title=String(p.title||"").trim(); if(!title) return json({detail:"اسم البث مطلوب"},400);
      const r=await env.DB.prepare("INSERT INTO streams(title,description,image_url,iframe_code,status,sort_order) VALUES(?,?,?,?,?,?)").bind(title,p.description||null,p.image_url||null,iframe,p.status||"live",Number(p.sort_order||0)).run();
      return json({ok:true,id:r.meta.last_row_id});
    }
    if(edit && req.method==="PATCH"){
      const id=Number(edit[1]), p=await req.json(), x=await env.DB.prepare("SELECT * FROM streams WHERE id=?").bind(id).first(); if(!x)return json({detail:"Not found"},404);
      let iframe=x.iframe_code; if("iframe_code" in p){try{iframe=sanitizeIframe(p.iframe_code,env)}catch(e){return json({detail:e.message},400)}}
      await env.DB.prepare("UPDATE streams SET title=?,description=?,image_url=?,iframe_code=?,status=?,enabled=?,sort_order=? WHERE id=?").bind(p.title??x.title,p.description??x.description,p.image_url??x.image_url,iframe,p.status??x.status,"enabled" in p?(p.enabled?1:0):x.enabled,Number(p.sort_order??x.sort_order),id).run();
      return json({ok:true});
    }
    if(edit && req.method==="DELETE"){
      await env.DB.prepare("DELETE FROM streams WHERE id=?").bind(Number(edit[1])).run(); return json({ok:true});
    }
  }
  return json({detail:"Not found"},404);
}

async function handleMessage(env,m){
  if(!m?.from?.id) return; const uid=Number(m.from.id); await ensureUser(env,m.from);
  const text=String(m.text||"");
  if(text.startsWith("/start")){
    if(!(await subscribed(env,uid))){ const cs=await channels(env); const rows=cs.map(c=>[{text:`📢 ${c.title}`,url:c.invite_url}]); rows.push([{text:"✅ تحقق",callback_data:"check_sub"}]); await send(env,uid,"اشترك في القنوات المطلوبة أولًا.",{reply_markup:{inline_keyboard:rows}}); return; }
    if(await isAdmin(env,uid)) await send(env,uid,"🎛 لوحة الإدارة\nاختر العملية:",{reply_markup:adminKeyboard(env)});
    else await send(env,uid,"🎬 أهلاً بك",{reply_markup:{inline_keyboard:[[webAppButton(env)]]}});
    return;
  }
  if(text==="/admin"){
    if(await isAdmin(env,uid)) await send(env,uid,"🎛 لوحة الإدارة",{reply_markup:adminKeyboard(env)}); else await send(env,uid,"غير مصرح."); return;
  }
  if(text.startsWith("/addadmin ") && isSuperDb(env,uid)){
    const id=Number(text.split(/\s+/)[1]); if(!id)return send(env,uid,"الاستخدام: /addadmin 123456789");
    await env.DB.prepare("INSERT OR IGNORE INTO admins(telegram_id,role) VALUES(?,?)").bind(id,"admin").run(); return send(env,uid,"✅ تم إضافة الأدمن.");
  }
  if(text.startsWith("/deladmin ") && isSuperDb(env,uid)){
    const id=Number(text.split(/\s+/)[1]); if(id) await env.DB.prepare("DELETE FROM admins WHERE telegram_id=? AND role!='super'").bind(id).run(); return send(env,uid,"✅ تم حذف الأدمن.");
  }
  if(text.startsWith("/addchannel ") && isSuperDb(env,uid)){
    try{const [chat,title,url]=text.slice(12).split("|").map(x=>x.trim()); if(!chat||!title||!url)throw 0; await env.DB.prepare("INSERT INTO required_channels(chat_id,title,invite_url) VALUES(?,?,?)").bind(Number(chat),title,url).run(); return send(env,uid,"✅ تمت إضافة القناة.")}catch(_){return send(env,uid,"الصيغة: /addchannel CHAT_ID | العنوان | الرابط")}
  }
  if(text.startsWith("/delchannel ") && isSuperDb(env,uid)){
    const id=Number(text.split(/\s+/)[1]); if(id)await env.DB.prepare("DELETE FROM required_channels WHERE chat_id=?").bind(id).run(); return send(env,uid,"✅ تم حذف القناة.");
  }
}

async function handleCallback(env,c){
  const uid=Number(c.from?.id), data=c.data||""; await ensureUser(env,c.from);
  await tg(env,"answerCallbackQuery",{callback_query_id:c.id});
  if(data==="check_sub"){
    if(await subscribed(env,uid)) await send(env,uid,"✅ تم التحقق. أرسل /start."); else await tg(env,"answerCallbackQuery",{callback_query_id:c.id,text:"❌ ما زال الاشتراك مطلوبًا.",show_alert:true}); return;
  }
  if(!(await isAdmin(env,uid))) return;
  if(data==="adm_stats"){
    const [u,s,v]=await Promise.all([env.DB.prepare("SELECT COUNT(*) n FROM users").first(),env.DB.prepare("SELECT COUNT(*) n FROM streams").first(),env.DB.prepare("SELECT COALESCE(SUM(views),0) n FROM streams").first()]);
    return send(env,uid,`📊 الإحصائيات\n\n👥 المستخدمون: ${u?.n||0}\n📺 البثوث: ${s?.n||0}\n👁 المشاهدات: ${v?.n||0}`);
  }
  if(data==="adm_streams") return send(env,uid,"📺 إدارة البثوث\n\nاستخدم لوحة التطبيق لإضافة وتعديل البثوث.",{reply_markup:{inline_keyboard:[[webAppButton(env,"📺 فتح الإدارة")]]}});
  if(data==="adm_admins") return send(env,uid,"👨‍💻 إدارة الأدمن:\n/addadmin USER_ID\n/deladmin USER_ID");
  if(data==="adm_channels") return send(env,uid,"📢 إدارة القنوات:\n/addchannel CHAT_ID | العنوان | رابط_الاشتراك\n/delchannel CHAT_ID");
  if(data==="adm_broadcast") return send(env,uid,"📣 الإذاعة الجماعية يمكن إضافتها لاحقًا.\n\nاستخدم لوحة الإدارة للبثوث والإحصائيات الآن.");
}

export default {
  async fetch(req,env,ctx){
    const url=new URL(req.url);
    if(url.pathname==="/telegram/webhook" && req.method==="POST"){
      try{const update=await req.json(); if(update.message)ctx.waitUntil(handleMessage(env,update.message)); if(update.callback_query)ctx.waitUntil(handleCallback(env,update.callback_query)); return json({ok:true});}catch(e){return json({ok:false,error:e.message},500)}
    }
    if(url.pathname==="/telegram/set-webhook"){
      if(req.method==="GET") return html(`<form method="post"><h3>Set Telegram webhook</h3><input name="key" type="password" placeholder="SETUP_KEY" required><button>Set webhook</button></form>`);
      const form=await req.formData(); if(form.get("key")!==env.SETUP_KEY) return html("Forbidden",403);
      const result=await tg(env,"setWebhook",{url:`${url.origin}/telegram/webhook`}); return json({ok:true,result});
    }
    if(url.pathname.startsWith("/api/")) return api(req,env,url);
    if(url.pathname==="/healthz") return json({ok:true});
    if(url.pathname==="/") return env.ASSETS.fetch(new Request(new URL("/index.html",url),req));
    return env.ASSETS.fetch(req);
  }
};
