# Telegram Stream Bot — Cloudflare Workers + D1

هذه نسخة Cloudflare من المشروع السابق. تستخدم Telegram Webhook بدل polling، وCloudflare D1 بدل SQLite، وWorkers Static Assets للواجهة.

> استخدم فقط مصادر البث أو صفحات iframe التي تملك حق عرضها.

## ما تحتاجه
- حساب Cloudflare على Workers Free.
- Bot Token من BotFather.
- قاعدة D1.

## إعداد D1
1. أنشئ قاعدة D1 باسم `telegram_stream_bot` من Cloudflare Dashboard.
2. انسخ Database ID وضعه مكان `PUT_YOUR_D1_DATABASE_ID_HERE` في `wrangler.toml`.
3. نفّذ محتوى `schema.sql` مرة واحدة من محرر D1 SQL.

## متغيرات Worker
- `BOT_TOKEN` Secret
- `ADMIN_IDS` مثل `123456789`
- `WEBAPP_URL` رابط Worker النهائي، مثل `https://telegram-stream-bot.<subdomain>.workers.dev`
- `SETUP_KEY` قيمة عشوائية طويلة تستخدمها مرة واحدة لإعداد webhook
- `WEBAPP_SECRET_TTL` = `86400`
- `ALLOWED_IFRAME_HOSTS` اتركها فارغة للاختبار، أو ضع النطاقات المسموح بها مفصولة بفواصل.

## بعد أول Deploy
افتح:
`https://YOUR-WORKER.workers.dev/telegram/set-webhook`
وأدخل `SETUP_KEY`. بعدها يصبح Telegram Webhook فعالًا.

ثم تأكد أن `WEBAPP_URL` يساوي رابط Worker بالضبط، وأعد Deploy.

## ملاحظات
- Cloudflare Workers Free يسمح حتى 100,000 request يوميًا حاليًا.
- D1 Free لديه حدود يومية للقراءة والكتابة؛ عند تجاوزها تتوقف استعلامات D1 حتى إعادة الضبط اليومية.
- لا تضع BOT_TOKEN داخل الكود أو GitHub؛ ضعه كـ Secret في Cloudflare.
